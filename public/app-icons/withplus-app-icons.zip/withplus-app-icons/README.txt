WITH+ 앱 아이콘 (투명 없는 PNG)

app-store-ios-1024.png    : 애플 앱스토어 등록용 1024x1024 (모서리는 애플이 자동으로 둥글게 처리)
google-play-512.png       : 구글 플레이 스토어 등록용 512x512
android-adaptive-1024.png : 안드로이드 적응형 아이콘용(로고를 가운데 안전영역에 작게 배치)
icon-192.png              : 웹앱/안드로이드 192x192
apple-touch-icon-180.png  : 아이폰 홈 화면 180x180
